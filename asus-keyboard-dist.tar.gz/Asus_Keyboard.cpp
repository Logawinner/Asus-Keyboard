#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <vector>
#include <string>
#include <thread>
#include <chrono>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <unistd.h>
#include <signal.h>

/**
 * ============================================================================
 * Apostle Aura L7 - Asus Keyboard Management Suite
 * Version: 17.2.1 (Full Distribution - Speed Logic Fixed)
 * ============================================================================
 */

struct RGB { int r, g, b; };

struct AppData {
    std::vector<GtkWidget*> color_entries;
    std::vector<RGB> final_colors;
    
    int brightness;
    int transition_time; // Internally still 'time' for the delay logic
    
    GtkWidget *stack;
    GtkWidget *color_grid;
    GtkWidget *window;
    GtkWidget *overlay_container;
    GtkWidget *speed_scale;   
    GtkWidget *bright_scale;
    
    bool is_running = true;
    std::thread worker_thread;

    AppData() : is_running(true) {} 
};

const char *LOCK_FILE = "/tmp/asus_keyboard.lock";

void ensure_single_instance() {
    std::ifstream infile(LOCK_FILE);
    if (infile.good()) {
        pid_t old_pid;
        infile >> old_pid;
        if (old_pid > 0) {
            kill(old_pid, SIGTERM);
            std::this_thread::sleep_for(std::chrono::milliseconds(250)); 
        }
    }
    infile.close();
    std::ofstream outfile(LOCK_FILE);
    if (outfile.is_open()) {
        outfile << getpid();
        outfile.close();
    }
}

const char *APOSTLE_CSS = 
    "window, .main-viewport { background-color: transparent !important; background-image: linear-gradient(135deg, #0f0202 0%, #020f05 45%, #02050f 100%) !important; } "
    ".main-viewport { padding: 45px; } "
    ".persistent-bar { background: rgba(10, 10, 10, 1.0); border-bottom: 2px solid transparent; background-image: linear-gradient(rgba(10,10,10,1.0), rgba(10,10,10,1.0)), linear-gradient(90deg, #ff00ff 0%, #00ffff 25%, #00ff00 50%, #ffff00 75%, #ff00ff 100%); background-origin: padding-box, border-box; background-clip: padding-box, border-box; padding: 10px 20px; } "
    ".control-label { font-weight: 900; color: #ffffff; font-size: 15pt; } "
    ".nav-button { background: #151515; border: 1px solid #00ffff; border-radius: 4px; padding: 5px 15px; margin-left: 8px; color: #00ffff; font-weight: bold; } "
    ".nav-button:hover { background: #004422; color: #ffffff; border-color: #00ff88; } "
    ".nav-button.exit { border-color: #ff00ff; color: #ff00ff; } "
    ".nav-button.exit:hover { background: #880000; color: #ffffff; border-color: #ff0000; } "
    "button.action-btn { background: #000; color: #00ff88 !important; font-weight: 800; border: 2px solid #00ff88; padding: 22px; font-size: 14pt; margin-top: 20px; text-transform: uppercase; box-shadow: none; } "
    "button.action-btn:hover { background: #004422; color: #ffffff !important; border-color: #00ff88; box-shadow: none; } "
    "entry { background: #000 !important; color: #00ff88 !important; border: 1px solid #00ff88; padding: 12px; } "
    "label { color: #ffffff !important; font-weight: bold; } "
    "scale trough { background-color: #000; min-height: 20px; border: 1px solid #333; } "
    "scale highlight { background-image: linear-gradient(90deg, #00ffff, #ff00ff); } "
    "scrolledwindow { background: rgba(0,0,0,0.7); border: 1px solid #00ffff; }";

RGB hsv_to_rgb(float h, float s, float v) {
    float r, g, b;
    int i = floor(h * 6);
    float f = h * 6 - i;
    float p = v * (1 - s);
    float q = v * (1 - f * s);
    float t = v * (1 - (1 - f) * s);
    switch (i % 6) {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = t; break;
    }
    return {(int)(r * 255), (int)(g * 255), (int)(b * 255)};
}

RGB hex_to_rgb(std::string hex) {
    if(hex[0] == '#') hex.erase(0, 1);
    try {
        return {(int)std::strtol(hex.substr(0, 2).c_str(), NULL, 16), 
                (int)std::strtol(hex.substr(2, 2).c_str(), NULL, 16), 
                (int)std::strtol(hex.substr(4, 2).c_str(), NULL, 16)};
    } catch (...) { return {0, 255, 136}; }
}

void hardware_loop(AppData *data) {
    int last_applied_brt = -1;
    const int steps = 24; 

    while (data->is_running) {
        if (data->brightness != last_applied_brt) {
            std::string levels[] = {"off", "low", "med", "high"};
            std::string selected = levels[std::clamp(data->brightness, 0, 3)];
            system(("asusctl leds set " + selected + " > /dev/null 2>&1").c_str());
            last_applied_brt = data->brightness;
        }

        if (data->final_colors.empty()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            continue;
        }

        for (size_t i = 0; i < data->final_colors.size(); ++i) {
            RGB start = data->final_colors[i];
            RGB end = data->final_colors[(i + 1) % data->final_colors.size()];

            for (int s = 0; s <= steps; ++s) {
                if (!data->is_running) return;

                float t = (float)s / steps;
                int r = std::round(start.r + t * (end.r - start.r));
                int g = std::round(start.g + t * (end.g - start.g));
                int b = std::round(start.b + t * (end.b - start.b));

                char hex[7];
                sprintf(hex, "%02x%02x%02x", r, g, b);
                system(("asusctl aura effect static --colour " + std::string(hex) + " > /dev/null 2>&1").c_str());

                // Logic: High value = High delay = Slow Speed.
                int base_delay = data->transition_time * 160; 
                int safety_floor = 15000; 
                std::this_thread::sleep_for(std::chrono::microseconds(base_delay + safety_floor));
            }
        }
    }
}

static void cb_sync_speed(GtkRange *range, gpointer user_data) {
    ((AppData*)user_data)->transition_time = (int)gtk_range_get_value(range);
}

static void cb_sync_bright(GtkRange *range, gpointer user_data) {
    ((AppData*)user_data)->brightness = (int)gtk_range_get_value(range);
}

static void cb_minimize(GtkWidget *w, gpointer win) { gtk_window_iconify(GTK_WINDOW(win)); }
static void cb_kill_app(GtkWidget *w, gpointer user_data) {
    unlink(LOCK_FILE); 
    exit(0); 
}

static void cb_init_keyboard(GtkWidget *btn, gpointer user_data) {
    AppData *data = (AppData*)user_data;
    
    // Explicit Sync on button press
    data->transition_time = (int)gtk_range_get_value(GTK_RANGE(data->speed_scale));
    data->brightness = (int)gtk_range_get_value(GTK_RANGE(data->bright_scale));

    GtkWidget *spin = (GtkWidget*)g_object_get_data(G_OBJECT(btn), "spin");
    int count = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));
    
    GList *children = gtk_container_get_children(GTK_CONTAINER(data->color_grid));
    for(GList *it = children; it != NULL; it = it->next) gtk_widget_destroy(GTK_WIDGET(it->data));
    g_list_free(children);
    data->color_entries.clear();

    const float GOLDEN_RATIO_CONJUGATE = 0.618033988749895f;
    float current_hue = 0.0f;
    for (int i = 0; i < count; i++) {
        current_hue = std::fmod(current_hue + GOLDEN_RATIO_CONJUGATE, 1.0f);
        RGB soft = hsv_to_rgb(current_hue, 0.85f, 0.95f);
        char hex[8]; sprintf(hex, "%02x%02x%02x", soft.r, soft.g, soft.b);
        GtkWidget *entry = gtk_entry_new();
        gtk_entry_set_text(GTK_ENTRY(entry), hex);
        gtk_grid_attach(GTK_GRID(data->color_grid), gtk_label_new(("COLOR " + std::to_string(i+1)).c_str()), 0, i, 1, 1);
        gtk_grid_attach(GTK_GRID(data->color_grid), entry, 1, i, 1, 1);
        data->color_entries.push_back(entry);
    }
    gtk_widget_show_all(data->color_grid);
    gtk_stack_set_visible_child_name(GTK_STACK(data->stack), "page2");
}

static void cb_run_loop(GtkWidget *btn, gpointer user_data) {
    AppData *data = (AppData*)user_data;
    data->final_colors.clear();
    
    // Sync again before launching thread
    data->transition_time = (int)gtk_range_get_value(GTK_RANGE(data->speed_scale));
    data->brightness = (int)gtk_range_get_value(GTK_RANGE(data->bright_scale));

    for (auto* e : data->color_entries) data->final_colors.push_back(hex_to_rgb(gtk_entry_get_text(GTK_ENTRY(e))));
    gtk_widget_hide(data->window);
    data->worker_thread = std::thread(hardware_loop, data);
    data->worker_thread.detach();
}

static void activate(GtkApplication *app, gpointer user_data) {
    AppData *data = (AppData*)user_data;
    GtkCssProvider *provider = gtk_css_provider_new();
    gtk_css_provider_load_from_data(provider, APOSTLE_CSS, -1, NULL);
    gtk_style_context_add_provider_for_screen(gdk_screen_get_default(), GTK_STYLE_PROVIDER(provider), 800);

    data->window = gtk_application_window_new(app);
    gtk_window_set_decorated(GTK_WINDOW(data->window), FALSE);
    gtk_window_set_icon_from_file(GTK_WINDOW(data->window), "/home/logawinner/Downloads/Gemini_Generated_Image_mvefpkmvefpkmvef.png", NULL);

    data->overlay_container = gtk_overlay_new();
    gtk_container_add(GTK_CONTAINER(data->window), data->overlay_container);

    GtkWidget *header = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_widget_set_valign(header, GTK_ALIGN_START);
    gtk_style_context_add_class(gtk_widget_get_style_context(header), "persistent-bar");
    
    GtkWidget *title = gtk_label_new("Asus Keyboard");
    gtk_style_context_add_class(gtk_widget_get_style_context(title), "control-label");
    gtk_box_pack_start(GTK_BOX(header), title, TRUE, TRUE, 0);

    GtkWidget *b_min = gtk_button_new_with_label("_");
    GtkWidget *b_exit = gtk_button_new_with_label("X");
    gtk_style_context_add_class(gtk_widget_get_style_context(b_min), "nav-button");
    gtk_style_context_add_class(gtk_widget_get_style_context(b_exit), "nav-button");
    gtk_style_context_add_class(gtk_widget_get_style_context(b_exit), "exit");

    g_signal_connect(b_min, "clicked", G_CALLBACK(cb_minimize), data->window);
    g_signal_connect(b_exit, "clicked", G_CALLBACK(cb_kill_app), data);
    gtk_box_pack_start(GTK_BOX(header), b_min, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(header), b_exit, FALSE, FALSE, 0);

    gtk_overlay_add_overlay(GTK_OVERLAY(data->overlay_container), header);

    GtkWidget *main_viewport = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_style_context_add_class(gtk_widget_get_style_context(main_viewport), "main-viewport");
    gtk_container_add(GTK_CONTAINER(data->overlay_container), main_viewport);

    GtkWidget *header_offset = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_widget_set_size_request(header_offset, -1, 65); 
    gtk_box_pack_start(GTK_BOX(main_viewport), header_offset, FALSE, FALSE, 0);

    data->stack = gtk_stack_new();
    gtk_box_pack_start(GTK_BOX(main_viewport), data->stack, TRUE, TRUE, 0);

    GtkWidget *setup = gtk_grid_new();
    gtk_widget_set_halign(setup, GTK_ALIGN_CENTER);
    gtk_widget_set_valign(setup, GTK_ALIGN_CENTER);
    gtk_grid_set_row_spacing(GTK_GRID(setup), 45);
    gtk_grid_set_column_spacing(GTK_GRID(setup), 40);

    GtkWidget *spin = gtk_spin_button_new_with_range(1, 256, 1);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin), 32); 

    data->bright_scale = gtk_scale_new_with_range(GTK_ORIENTATION_HORIZONTAL, 0, 3, 1);
    gtk_range_set_value(GTK_RANGE(data->bright_scale), 2);
    data->brightness = 2; // Sync internal var
    g_signal_connect(data->bright_scale, "value-changed", G_CALLBACK(cb_sync_bright), data);

    data->speed_scale = gtk_scale_new_with_range(GTK_ORIENTATION_HORIZONTAL, 1, 1000, 1);
    gtk_range_set_value(GTK_RANGE(data->speed_scale), 30);
    data->transition_time = 30; // Sync internal var
    g_signal_connect(data->speed_scale, "value-changed", G_CALLBACK(cb_sync_speed), data);

    GtkWidget *btn_init = gtk_button_new_with_label("INITIALIZE KEYBOARD");
    gtk_style_context_add_class(gtk_widget_get_style_context(btn_init), "action-btn");
    
    gtk_grid_attach(GTK_GRID(setup), gtk_label_new("TOTAL SLOTS:"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(setup), spin, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(setup), gtk_label_new("BRIGHTNESS:"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(setup), data->bright_scale, 1, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(setup), gtk_label_new("TRANSITION TIME (1-1000):"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(setup), data->speed_scale, 1, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(setup), btn_init, 0, 3, 2, 1);

    g_object_set_data(G_OBJECT(btn_init), "spin", spin);
    g_signal_connect(btn_init, "clicked", G_CALLBACK(cb_init_keyboard), data);

    GtkWidget *map_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 25);
    GtkWidget *scroll = gtk_scrolled_window_new(NULL, NULL);
    data->color_grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(data->color_grid), 12);
    gtk_grid_set_column_spacing(GTK_GRID(data->color_grid), 20);
    gtk_container_add(GTK_CONTAINER(scroll), data->color_grid);
    GtkWidget *btn_loop = gtk_button_new_with_label("RUN COLOR LOOP");
    gtk_style_context_add_class(gtk_widget_get_style_context(btn_loop), "action-btn");
    g_signal_connect(btn_loop, "clicked", G_CALLBACK(cb_run_loop), data);

    gtk_box_pack_start(GTK_BOX(map_box), scroll, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(map_box), btn_loop, FALSE, FALSE, 0);

    gtk_stack_add_named(GTK_STACK(data->stack), setup, "page1");
    gtk_stack_add_named(GTK_STACK(data->stack), map_box, "page2");
    
    gtk_widget_show_all(data->window);
    gtk_window_maximize(GTK_WINDOW(data->window));
}

int main(int argc, char **argv) {
    ensure_single_instance();
    AppData *data = new AppData();
    GtkApplication *app = gtk_application_new("org.apostle.keyboard", G_APPLICATION_FLAGS_NONE);
    g_signal_connect(app, "activate", G_CALLBACK(activate), data);
    return g_application_run(G_APPLICATION(app), argc, argv);
}